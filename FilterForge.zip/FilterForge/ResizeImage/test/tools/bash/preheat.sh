#!/bin/bash

./partestcpu.sh $1 $2 $3 $4 > /dev/null
./partestcpu.sh $1 $2 $3 $4