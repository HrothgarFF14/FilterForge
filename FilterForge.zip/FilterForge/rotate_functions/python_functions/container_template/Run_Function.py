import FaaSET

results = FaaSET.bash_container({})
print(results["standard_output"])